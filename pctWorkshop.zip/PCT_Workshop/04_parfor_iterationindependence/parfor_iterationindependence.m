%% Identify the issue with the following code
A = 0;
parfor ii = 2:10
    A(ii) = A(ii-1) + rand();
end