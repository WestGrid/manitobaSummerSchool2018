% This example shows how parfeval can be more efficient than parfor if the
% length of the iterations is known a priori.  In general, you want to run
% the longest iterations first so that you don't have to wait for one long
% iteration to finish at the end.

% Time to pause, sorted ascending
pausetime = [1 1 2 2 6 6 6]; 

%% Parfor
% Load balancing is automatic.  Parfor does not know that the later
% iterations take longer.

disp('Parfor:')
tic
parfor ii = 1:numel(pausetime)
    pause(pausetime(ii))
end
toc

%% Parfeval
% Schedule most expensive iterations first.

disp('Parfeval:')
tic
% Offload all iterations
for ii = numel(pausetime):-1:1
    iter(ii) = parfeval(@(x)pause(x), 0, pausetime(ii));  
end
% Query them back asyncronously as they become available
for jj = 1:numel(pausetime)
    fetchNext(iter);
end
toc