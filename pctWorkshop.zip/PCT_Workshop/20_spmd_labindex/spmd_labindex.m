%% Hint

doc labindex

%% 
x = (0:0.01:6).';

%% Compute the sine of x on lab 1


%% Compute the cosine of x on lab 2


%% Display results at the command line


%% Plot results


