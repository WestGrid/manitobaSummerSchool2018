%% Hints

doc labSend
doc labReceive
doc numlabs

%% Generate different data on each worker


%% N-by-N matrix filled with Ns (N = labindex)


%% Send data from lab 1 to lab 2 and so on


%% Receiving data on each worker


%% Display received data on each worker


%% Fetch data back to client


