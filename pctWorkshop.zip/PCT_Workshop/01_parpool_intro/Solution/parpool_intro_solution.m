%% Hint: 

doc parpool


%% Open and close a parallel pool interactively
% Hint: look at bottom left corner of MATLAB desktop


%% Open pool of 2 local MATLAB workers

parpool(2)


%% Query size of pool of workers
% Hint:  How do you handle the case of no pool being open?
%

poolobj = gcp('nocreate'); % If no pool, do not create new one.
if isempty(poolobj)
    poolsize = 0;
else
    poolsize = poolobj.NumWorkers;
end
disp(poolsize)

%% Close pool of workers

delete(gcp)

