%% This is an Example Script
% 

% Generate some data.
x = 1:100;
y = sin(x)+randn(size(x))./pi;