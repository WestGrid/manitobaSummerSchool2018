%% Run the following piece of code several times
gcp; % open parallel pool if none is open
parfor ii=1:9
    disp(ii) % iteration
    pause(randi(5))
end

