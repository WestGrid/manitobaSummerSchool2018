%% Loading and Saving in PARFOR
% parfor-loops need to be able to recognize every variable inside of them.
% For this reason, loading and saving are restricted.
% 
% Convert the for-loop to parfor.
%
% Hint: See this doc page
%   >>web(fullfile(docroot, 'distcomp/transparency.html'))
%

parfor ii = 1:2
    S = load('xy.mat')
    x = S.x;
    y = S.y;
    z = x*y*rand;
    parsave(z,ii);
end

%% Function
% Note local functions in scripts added in R2016b.  In previous releases
% this would have to be in a separate file or the parent would have to be a
% function.

function parsave(z,ii) 
    % Write to separate files in parfor to avoid race conditions.
    save(['z' num2str(ii) '.mat'], 'z')
end
% Turn off code analyzer warning since z is saved.
%#ok<*INUSL>
