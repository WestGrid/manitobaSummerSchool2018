%% Loading and Saving in PARFOR
% parfor-loops need to be able to recognize every variable inside of them.
% For this reason, loading and saving are restricted.
% 
% Convert the for-loop to parfor.
%
% Hint: See this doc page
%   >>web(fullfile(docroot, 'distcomp/transparency.html'))
%

parfor ii = 1:2
    load xy.mat
    z = x*y*rand;
    save(['z' num2str(ii) '.mat'], 'z')
end