function imageData = whitebalance_cuda(imageData)
% WHITEBALANCE_CUDA forces the average image color to be gray.

% Copy our image data to the GPU
imageData = gpuArray(imageData);

% Find the average values for each channel.
avg_rgb = mean(mean(imageData));

% Find the average gray value and compute the scaling factor.
factors = max(mean(avg_rgb), 128)./avg_rgb;

% Load the kernel
kernel = parallel.gpu.CUDAKernel('applyScaleFactors.ptx', 'applyScaleFactors.cu' );

% Set up the threads
[nRows, nCols, ~] = size(imageData);
blockSize = 256;
kernel.ThreadBlockSize = [blockSize, 1, 1];
kernel.GridSize = [1, nCols, 3];

% Apply the kernel to scale the color values (*FIXME 3*)
imageData = feval(kernel, imageData, factors, nRows, nCols);

% Copy data from the GPU back to main memory
imageData = gather(imageData);	
