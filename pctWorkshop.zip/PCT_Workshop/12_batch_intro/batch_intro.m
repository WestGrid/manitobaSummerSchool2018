%% Batch Intro
%

doc batch


%% Offload serial computation
% Use batch command to offload serial computation to one worker
% Use the 50 and 10000 as the inputs to ex_serial.
%
% Call it job1

%% Open the Parallel Job Monitor
%
% Home Tab -> Parallel -> Job Monitor
%
% Look at the state of your job


%% Get the results from job1 back to client (interactively)


%% Offload parallel computation
% Use the batch command to offload ex_parallel to a pool of workers.
% Use the 50 and 10000 as the inputs to ex_parallel.
%
% Hint: The pool size should be one less than the number of workers in the
% pool.  Why?
%
% Call it job2


%% Query the state of job2 programatically


%% Wait for job2 to finish


%% Get results back to client (programatically)


%% Clean up
% Clean up job1 interactively from the job monitor
% Clean up job2 programatically

