function parfor_structcell
% The variable z is a structure.  Because structures have dynamic
% fieldnames, they cannot be sliced and need to be broadcast to the workers
% in their entirety.  Oftentimes, cells can replace structures and be
% sliced by index rather than fieldname.
%
% Convert z.data to a cell and use it instead.  
% Hint: num2cell()

z.data = rand(4,4);
z.unusedata = magic(100);
means = zeros(1,4);
parfor ii = 1:4
    means(ii) = mean(z.data(:,ii));
end
disp(means)
