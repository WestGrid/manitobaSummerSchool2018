%% Truss Deflection - Parameter Sweep
% This is a parameter sweep study of the effect of the number of elements
% and element cross sectional area on the displacement at the tip of a
% cantilevered truss.
%
% Copyright 2016 The MathWorks, Inc.
%

%% Initialize Problem

% Number of elements and cross sectional area of each element
nNum = 8; 
aNum = 8;

% Vectors of number of elements and cross section areas to sweep
nVals = (1:nNum)+10; % number of segments, start with 11
aVals = linspace(100, 200, aNum);  % cross sectional area
peakVals = nan(nNum,aNum); % Peak value results matrix


%% Parameter Sweep
%
% Write a parfor-loop to loop over every combination of aVals and nVals
% calling trussCantilever storing the peak deflection at the tip.
% trussCantilever is called with:
%
%    y = trussCantilever(n,a)
%    ypeak = max(y(:,end))    
%
% There are two ways of doing this, one with
% nested loops, the other with a grid.  For more information on the latter,
% see >>doc meshgrid
%
% Time this with a for-loop and a parfor-loop

%% First way

t0 = tic;
parfor ii = 1:nNum
    for jj = 1:aNum  % Solve ODE
        Y = trussCantilever(nVals(ii),aVals(jj));
    
        % Determine peak deflection in Y direction at the tip
        tempY = zeros(1,aNum);
        tempY(jj) = max(Y(:,end));
    end
    peakVals(ii,:) = tempY;
end
toc(t0)

%% Second way

% Grid of all combinations
[nGrid, aGrid] = meshgrid(nVals, aVals);

t0 = tic;
parfor ii = 1:numel(aGrid)
    % Solve ODE
    Y = trussCantilever(nGrid(ii),aGrid(ii));
    
    % Determine peak deflection in Y direction at the tip
    peakVals(ii) = max(Y(:,end));    
end
toc(t0)

%% Visualize results
% Show the parameter sweep grid results

visualizeParamSweep(nVals, aVals, peakVals);

