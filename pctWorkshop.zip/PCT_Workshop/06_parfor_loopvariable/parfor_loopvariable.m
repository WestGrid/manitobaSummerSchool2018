%% Parfor Loop Variable
% Take the following for-loop and turn it into a parfor-loop.
% What happens, does it run?
% Implement a workaround.

z = 0;
for x = 0:0.1:1
    z = z + x;
end
