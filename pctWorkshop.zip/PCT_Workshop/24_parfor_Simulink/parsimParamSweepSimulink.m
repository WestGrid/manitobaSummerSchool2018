%% About PARSIM
% Parsim was released in R2017a to simplify running of multiple
% simulations.  It allows for preconfiguring simulations and then
% simulating in parallel locally or on a cluster (even if that cluster is
% not the same operating system).
%
% Rapid Accelerator and Fast Restart are supported by it.
%% Numbers of P+K
bNum = 5;
kNum = 5; 

%% Mass damping and stiffness
bVals = linspace(0.1, 5, bNum);  % damping values
kVals = linspace(1.5, 5, kNum);  % stiffness values
[kGrid, bGrid] = meshgrid(bVals, kVals);

%% Set up Simulation
for ii = numel(kGrid):-1:1
    in(ii) = Simulink.SimulationInput('DampedOscillator');
    in(ii) = in(ii).setVariable('b',bGrid(ii));
    in(ii) = in(ii).setVariable('k',kGrid(ii));
end

%% Simulate
out = parsim(in, 'ShowProgress', true, 'UseFastRestart', true);


