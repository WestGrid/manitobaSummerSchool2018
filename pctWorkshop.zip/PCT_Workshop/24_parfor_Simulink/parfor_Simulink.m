function pv = parfor_Simulink(bNum, kNum)
%% Parameter Sweep of ODEs
% peakVals = parfor_simulink(bNum, kNum)
%
% This is a parameter sweep study of a 2nd order ODE system.
%
% $m\ddot{x} + b\dot{x} + kx = 0$
%
% The model itself has default parameters preconfigured with PreLoadFcn
% callback
%
% We solve the ODE for a time span of 0 to 25 seconds, with initial
% conditions $x(0) = 0$ and $\dot{x}(0) = 1$. We sweep the parameters $b$
% and $k$ and record the peak values of $x$ for each condition. At the end,
% we plot a surface of the results.
%
% Copyright 2009-2016 The MathWorks, Inc.

% Defaults
if nargin < 2
    bNum = 5;
    kNum = 5;
end

% Mass damping and stiffness
m = 5;    % mass
bVals = linspace(0.1, 5, bNum);  % damping values
kVals = linspace(1.5, 5, kNum);  % stiffness values
[kGrid, bGrid] = meshgrid(bVals, kVals);
peakVals = nan(size(kGrid));

% Pre-load the model on each Worker
mdl = 'DampedOscillator.slx';
spmd
    load_system(mdl);
end

% Parameter Sweep
t = tic;
parfor idx = 1:numel(kGrid)
    % Solve ODE
    Y = simDampedOscillator(mdl, bGrid(idx), kGrid(idx), m);
    
    % Determine peak value
    peakVals(idx) = max(Y(:,1));    
end
toc(t)

% Close the model on the workers
spmd
    close_system(mdl);
end

% Visualize and pass back output if requested
visualizeParamSweep(bVals, kVals, peakVals)
if nargout
    pv = peakVals;
end

end

function Y = simDampedOscillator(mdl, b, k, m)

x0 = 0;
x0_dot = 1;

% Note: once the model is loaded, it will stay loaded in workers,
%   so pre-loading with spmd in a seperate code block is a good workflow

% These over-ride values similarly loaded with the PreLoadFcn callback
assignin('base', 'D', k);
assignin('base', 'm', m);
assignin('base', 'R', b);
assignin('base', 'x0', x0);
assignin('base', 'x0_dot', x0_dot);
[~,Y] = sim(mdl);

end

