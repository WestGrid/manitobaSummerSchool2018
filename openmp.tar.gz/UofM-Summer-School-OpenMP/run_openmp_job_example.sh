#!/bin/bash

##SBATCH --reservation=wgssum-wr_cpu    # reservation.
#SBATCH --account=wgssum-wa_cpu        # Accounting group.
#SBATCH --ntasks=1                     # number of MPI processes.
#SBATCH --cpus-per-task=4              # number of threads.
#SBATCH --mem-per-cpu=2500M            # memory; default unit is megabytes.
#SBATCH --time=0-00:30                 # time (DD-HH:MM).

cd $SLURM_SUBMIT_DIR

# Load a module or modules if needed.

echo "Starting run at: `date`"
echo "Program running on `hostname` using $SLURM_CPUS_PER_TASK threads."

export OMP_NUM_THREADS=$SLURM_CPUS_PER_TASK

sleep 120   #./my_openmp_program_exec

echo "Program finished with exit code $? at: `date`"
