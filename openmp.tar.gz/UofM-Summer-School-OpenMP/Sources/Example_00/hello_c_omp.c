/*
 * ==============================================================================
 * Simple Hello World program: OpenMP Version.
 * Compile with:
 *    gcc -fopenmp hello_c_omp.c -o hello_c_omp
 *    icc -openmp hello_c_omp.c -o hello_c_omp
 * ==============================================================================
*/

#include <stdio.h>
#include <omp.h>             /* Add the Header to enable OpenMP Runtime Library */

int main() {

  #pragma omp parallel       /* Add #progrma omp parallel to a structured block */
  {

  printf("Hello World!\n");  /* Simple example of a structured block */ 

  }

}

/*
 * ==============================================================================
 * End of the program Hello World.
 * ==============================================================================
*/
