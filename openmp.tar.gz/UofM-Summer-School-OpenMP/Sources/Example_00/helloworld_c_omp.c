/*
 * ==============================================================================
 * Simple Hello World program: OpenMP Version.
 * Compile with:
 *    gcc -fopenmp helloworld_c_omp.c -o helloworld_c_omp
 *    icc -openmp helloworld_c_omp.c -o helloworld_c_omp
 * ==============================================================================
*/

#include <stdio.h>
#include <omp.h>           /* Add the Header to enable OpenMP Runtime Library */

#define NUM_THREADS 4      /* Define the number of threads as a constant      */      

int main() {

  int ID, nthr, nthreads;
  double start_time, end_time, elapsed_time;   /* Time variables to compute the cpu time used */

  printf("\nStart the program.\n\n");

  /* Set number of threads to NUM_THREADS */

  omp_set_num_threads(NUM_THREADS);

  /* To know how many threads are available outside the parallel region. */
 
  nthr = omp_get_num_threads();

  printf("I am out of the parallel region and the number of threads is: %d\n\n",nthr);

  printf("Start of the parallel region.\n\n");

  /* Store the time before starting the parallel region. */

  start_time = omp_get_wtime();

  /* Add OpenMP compiler directive to start a parallel region and create threads */

  #pragma omp parallel default(none) private(ID) shared(nthreads)
  {
     ID = omp_get_thread_num();         /* To get the thread number or rank */

     nthreads = omp_get_num_threads();  /* To get the number of threads in the parallel region. */
  
     printf("Hello World!; My ID is equal to [ %d ] - The total of threads is: [ %d ]\n",ID, nthreads);
  }

  /* Store the time after the parallel region. */

  end_time = omp_get_wtime();

  /* Compute time spend in the parallel region. */

  elapsed_time = end_time - start_time;

  printf("\nThe time spend in the parallel region is: %f\n\n",elapsed_time);

  printf("End of the parallel region.\n\n");

  /* To know how many threads are available outside the parallel region. */

  nthr = omp_get_num_threads();

  printf("Again, I am out of the parallel region and the number of threads is: %d\n\n",nthr);

  printf("End of the program.\n\n");

}

/*
 * ==============================================================================
 * End of the program Hello World.
 * ==============================================================================
*/
