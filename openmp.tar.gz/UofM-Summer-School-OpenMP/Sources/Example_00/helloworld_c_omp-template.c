/*
 * ==============================================================================
 * Simple Hello World program: OpenMP Version.
 * Compile with:
 *    gcc -fopenmp helloworld_c_omp-template.c
 *    icc -openmp helloworld_c_omp-template.c
 * ==============================================================================
*/

#include <stdio.h>
           /* Add the Header to enable OpenMP Runtime Library */

#define NUM_THREADS 4      /* Define the number of threads as a constant      */      

int main() {

  int ID, nthr, nthreads;
  double start_time, end_time, elapsed_time;   /* Time variables to compute the cpu time used */

  printf("\nStart the program.\n\n");

  /* Set number of threads to NUM_THREADS */

  ADD_OMP_DIRECTIVE_HERE; 

  /* To know how many threads are available outside the parallel region. */
 
  nthr = ADD_OMP_DIRECTIVE_HERE;

  printf("I am out of the parallel region and the number of threads is: %d\n\n",nthr);

  printf("Start of the parallel region.\n\n");

  /* Store the time before the parallel region. */

  start_time = ADD_OMP_DIRECTIVE_HERE;

  /* Add #pragma omp parallel to create threads */

  ADD_OMP_DIRECTIVE_HERE; 
  {
     ID = ADD_OMP_DIRECTIVE_HERE;           /* To get the thread number or rank */

     nthreads = ADD_OMP_DIRECTIVE_HERE;     /* To get the number of threads in the parallel region. */
  
     printf("Hello World!; My ID is equal to [ %d ] - The total of threads is: [ %d ]\n",ID, nthreads);
  }

  /* Store the time after the parallel region. */

  end_time = ADD_OMP_DIRECTIVE_HERE;

  /* Compute time spend in the parallel region. */

  elapsed_time = end_time - start_time;

  printf("\nThe time spend in the parallel region is: %f\n\n",elapsed_time);

  printf("End of the parallel region.\n\n");

  /* To know how many threads are available outside the parallel region. */

  nthr = ADD_OMP_DIRECTIVE_HERE;

  printf("Again, I am out of the parallel region and the number of threads is: %d\n\n",nthr);

  printf("End of the program.\n\n");

}

/*
 * ==============================================================================
 * End of the program Hello World.
 * ==============================================================================
*/
