/*
 * ==============================================================================
 * Simple Hello World program: OpenMP Version.
 * Compile with:
 *    gcc -fopenmp hello_c_omp-template.c
 *    icc -openmp hello_c_omp-template.c
 * ==============================================================================
*/

#include <stdio.h>

/* Add the Header to enable OpenMP Runtime Library */

ADD_OMP_DIRECTIVE_HERE;

int main() {

  /* Add OpenMP directive to create a parallel region */
  
  ADD_OMP_DIRECTIVE_HERE;
  
  {

  printf("Hello World!\n");  /* simple example of a structured block */ 

  }

}

/*
 * ==============================================================================
 * End of the program Hello World.
 * ==============================================================================
*/
