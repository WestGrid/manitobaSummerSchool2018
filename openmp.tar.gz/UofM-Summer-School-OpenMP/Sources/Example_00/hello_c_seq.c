/*
 * ==============================================================================
 * Simple Hello World program: Serial Version.
 * Compile with:
 *    gcc hello_c_seq.c -o hello_c_seq
 *    icc hello_c_seq.c -o hello_c_seq
 * ==============================================================================
*/

#include <stdio.h>

int main() {

  printf("Hello World!\n");

}

/*
 * ==============================================================================
 * End of the program Hello World.
 * ==============================================================================
*/
