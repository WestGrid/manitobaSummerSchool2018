/*
 * ==============================================================================
 * Simple Compute PI program using SPMD pattern.
 * Compile with:
 *    gcc -fopenmp compute_pi_c_spmd-template.c
 *    icc -openmp compute_pi_c_spmd-template.c
 * ==============================================================================
*/

#include <omp.h>
#include <stdio.h>
#include <math.h>
#include <time.h>

#define nb_steps 20000000                    /* Number of steps        */
#define step (1.0 / (double) nb_steps)      /* Width of the small rectangle */
#define MAX_THREADS 4

double pi;

int main() {
  double start_time, end_time, elapsed_time;   /* Time variables to compute the cpu time used */
  double pi;
  int i, j;
  double sum[MAX_THREADS];
  double tot_sum = 0.0; 
  
  for (j = 1; j <= MAX_THREADS; j++) {

      ADD_OMP_DIRECTIVES_HERE;                     /* Set number of threads to j */

      tot_sum = 0.0;

      start_time = ADD_OMP_DIRECTIVE_HERE;         /* Get the start time */                         

      ADD_OMP_DIRECTIVE_HERE;                      /* Start parallel region */ 
      {
        int i;
        int id = ADD_OMP_DIRECTIVE_HERE;           /* get thred ID */ 
        int numthreads = ADD_OMP_DIRECTIVE_HERE;   /* Get number of threads */
        double x;

        sum[id] = 0.0;                                /* Initialize the sum variable. */ 

        if (id == 0) { printf(" The Number of Threads = %d \n", numthreads); }

        for (i = id; i < nb_steps; i+=numthreads) {     /* Loop over the number of steps. */
            x = (i + 0.5) * step;                       /* Compute the position of the rectangle. */
            sum[id] = sum[id] + 1.0/(1.0 + x * x);      /* Update the sum by adding the surface of the current rectangle. */
        }
      }

      for (i = 0; i < j; i++) { tot_sum += sum[i]; }

      pi = 4.0 * tot_sum * step;                     /* Multiply by the factor: 4.0 * step */

      end_time = ADD_OMP_DIRECTIVE_HERE;             /* Get the end time */

      /* Compute the elapsed time in seconds */

      elapsed_time = ((double) (end_time - start_time)) ;

      /* Print out the results: pi value, number of steps, elapsed time */

      printf("The value of pi is [ %15.12lf ]; Computed using [ %ld ] steps in [ %15.12lf ]  seconds\n",pi,nb_steps,elapsed_time);

  }

}

// End of the program Compute Pi.
