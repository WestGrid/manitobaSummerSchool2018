/*
 * ==============================================================================
 * Simple program using sections in OpenMP.
 * Compile with:
 *    gcc -fopenmp helloworld_section_c_omp-template.c 
 *    icc -openmp helloworld_section_c_omp-template.c
 * ==============================================================================
*/

#include <stdio.h>
#include <omp.h>     /* Add the Header to enable OpenMP Runtime Library */

int main() {

ADD_OMP_DIRECTIVE_HERE;   /* Add a directiove to create parallel sections. */ 

   {
   ADD_OMP_DIRECTIVE_HERE   /* Start a section */
      { 
         printf ("First section, My ID = %d, \n", omp_get_thread_num());
      }
   ADD_OMP_DIRECTIVE_HERE   /* Start a section */
   { 
         printf ("Second Section, My ID = %d, \n", omp_get_thread_num());
      }
   ADD_OMP_DIRECTIVE_HERE   /* Start a section */
      {
         printf ("Third Section, My ID = %d, \n", omp_get_thread_num());
      }
   }
}

/*
 * ==============================================================================
 * End of the program.
 * ==============================================================================
*/
