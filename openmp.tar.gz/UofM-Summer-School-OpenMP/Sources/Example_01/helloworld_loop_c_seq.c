/*
 * ==============================================================================
 * Simple Hello World program: Serial Version.
 * Compile with:
 *    gcc helloworld_c_seq.c -o helloworld_c_seq
 *    icc helloworld_c_seq.c -o helloworld_c_seq
 * ==============================================================================
*/

#include <stdio.h>

#define nloops 8

int main() {

  int ID = 0;
  int i;

  for (i = 0; i < nloops; i++) {
       printf("Hello World!; My ID is equal to [ %d ] - I get the value [ %d ]\n",ID,i);
  }
}

/*
 * ==============================================================================
 * End of the program Hello World.
 * ==============================================================================
*/
