/*
 * ==============================================================================
 * Simple program using sections in OpenMP.
 * Compile with:
 *    gcc -fopenmp helloworld_section_c_omp.c -o helloworld_secion_c_omp
 *    icc -openmp helloworld_section_c_omp.c -o helloworld_section_c_omp
 * ==============================================================================
*/

#include <stdio.h>
#include <omp.h>     /* Add the Header to enable OpenMP Runtime Library */

int main() {

#pragma omp parallel sections
   {
   #pragma omp section
      { 
         printf ("First section, My ID = %d, \n", omp_get_thread_num());
      }
   #pragma omp section
      { 
         printf ("Second Section, My ID = %d, \n", omp_get_thread_num());
      }
   #pragma omp section
      {
         printf ("Third Section, My ID = %d, \n", omp_get_thread_num());
      }
   }
}

/*
 * ==============================================================================
 * End of the program.
 * ==============================================================================
*/
