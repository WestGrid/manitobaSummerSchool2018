/*
 * ==============================================================================
 * Simple Hello World program: OpenMP Version.
 * Compile with:
 *    gcc -fopenmp helloworld_loop_c_omp-template.c 
 *    icc -openmp helloworld_loop_c_omp-template.c
 * ==============================================================================
*/

#include <stdio.h>
#include <omp.h>     /* Add the Header to enable OpenMP Runtime Library */

#define nloops 8
 
int main() {

  int ID, nthreads;

  ADD_OMP_DIRECTIVE_HERE; 
  {
     int i;
     ID = omp_get_thread_num();

     /* Let us store the variable nthreads. Pick one thread to store it (ID = 0) */

     if (ID == 0) { nthreads = omp_get_num_threads(); }
   
     /* Here, we replace the previous line by a single construct.*/
 
     ADD_OMP_DIRECTIVE_HERE;
        nthreads = omp_get_num_threads();
 
     ADD_OMP_DIRECTIVE_HERE; 
     for (i = 0; i < nloops; i++) { 
          printf("Hello World!; My ID is equal to [ %d of %d ] - I get the value [ %d ]\n",ID,nthreads,i);
     }
  }

}

/*
 * ==============================================================================
 * End of the program Hello World.
 * ==============================================================================
*/
