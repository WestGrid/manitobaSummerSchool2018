#!/bin/bash

wget http://lammps.sandia.gov/tars/lammps-stable.tar.gz

echo "Done"
