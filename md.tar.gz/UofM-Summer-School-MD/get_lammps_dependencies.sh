#!/bin/bash

module load nixpkgs/16.09
module load StdEnv/2016.4
module load eigen/3.3.2
module load fftw-mpi/3.3.6
module load voro++/0.4.6
module load hdf5/1.8.18
module load vtk/6.3.0
module load netcdf/4.4.1.1
module load python/2.7.13
module load kim/1.8.2

echo "Done"
