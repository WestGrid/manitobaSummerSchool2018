#!/bin/bash

for directory in Procs_1  Procs_16  Procs_2  Procs_4  Procs_8 ; do
  if [ -d "${directory}" ] ; then
     cd ${directory}
     sbatch run_lmp.sh
     cd ../
  fi
done

echo "Done"
